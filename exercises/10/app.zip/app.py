def handler(event, handler):
    return "Hello from Lambda!"
